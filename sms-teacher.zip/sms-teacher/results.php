<?php
/**
 * Results Processing Handler
 * Receives uploaded Excel files, parses them, validates scores, calculates grades, and updates the database.
 */

header('Content-Type: application/json');
session_start();

require_once 'config/database.php';
require_once 'SimpleXLSXParser.php';
require_once 'security.php';

// Initialize session security
SessionSecurity::init();

// Authentication
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'teacher') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

// CSRF Protection
CSRF::validateRequest(true);

// Check Input
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid Request Method']);
    exit;
}

// Rate Limiting (5 uploads per 5 minutes)
if (!RateLimiter::check('result_upload', 5, 300)) {
    $remaining = RateLimiter::getRemainingTime('result_upload', 300);
    echo json_encode([
        'success' => false, 
        'message' => "Too many upload attempts. Please wait " . ceil($remaining / 60) . " minutes before trying again."
    ]);
    exit;
}

if (!isset($_FILES['result_file']) || $_FILES['result_file']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['success' => false, 'message' => 'File upload failed.']);
    exit;
}


$class_id = $_POST['class_id'] ?? null;
$session_id = $_POST['session_id'] ?? null;
$term_id = $_POST['term_id'] ?? null;

if (!$class_id || !$session_id || !$term_id) {
    echo json_encode(['success' => false, 'message' => 'Missing Class, Session or Term ID.']);
    exit;
}

// Validate file size (5MB limit)
$maxFileSize = 5 * 1024 * 1024; // 5MB in bytes
if ($_FILES['result_file']['size'] > $maxFileSize) {
    echo json_encode(['success' => false, 'message' => 'File too large. Maximum file size is 5MB.']);
    exit;
}

// Validate file extension and MIME type
$fileName = $_FILES['result_file']['name'];
$fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
$fileTmpPath = $_FILES['result_file']['tmp_name'];

if (!in_array($fileExtension, ['xls', 'xlsx'])) {
    error_log("Results upload failed: Invalid file extension '$fileExtension' from user {$_SESSION['user_id']}");
    echo json_encode(['success' => false, 'message' => 'Invalid file type. Only .xls and .xlsx files are allowed.']);
    exit;
}

// Check MIME type for additional security
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mimeType = finfo_file($finfo, $fileTmpPath);
finfo_close($finfo);

$allowedMimes = [
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/octet-stream' // Some systems report this for Excel files
];

if (!in_array($mimeType, $allowedMimes)) {
    error_log("Results upload failed: Invalid MIME type '$mimeType' for file '$fileName' from user {$_SESSION['user_id']}");
    echo json_encode(['success' => false, 'message' => 'Invalid file type detected. Please upload a valid Excel file.']);
    exit;
}


try {
    $db = (new Database())->getConnection();
    
    // 1. Parse File
    $parser = new SimpleXLSXParser();
    try {
        $rows = $parser->parse($fileTmpPath);
        error_log("Results upload: Successfully parsed Excel file '$fileName' with " . count($rows) . " rows for user {$_SESSION['user_id']}");
    } catch (Exception $e) {
        error_log("Results upload failed: Excel parse error - " . $e->getMessage() . " for file '$fileName' from user {$_SESSION['user_id']}");
        echo json_encode(['success' => false, 'message' => 'Unable to read Excel file. Please ensure the file is not corrupted and follows the template format.']);
        exit;
    }
    
    if (count($rows) < 3) {
        error_log("Results upload failed: Insufficient rows in file '$fileName' (" . count($rows) . " rows) from user {$_SESSION['user_id']}");
        throw new Exception("File appears to be empty or missing header rows. Please use the correct template format.");
    }

    // 2. Identify Structure
    // Row 1: Student ID | Student Name | Subject A | ...
    // Row 2: ... | ... | CA | Exam | CA | Exam
    $headerRow1 = $rows[0];
    $headerRow2 = $rows[1];
    
    // Identify Subjects from Header Row 1
    // Format: ID (0), Name (1), Sub1 (2), (Merged 3), Sub2 (4), (Merged 5)...
    // Actually, in parsed array, merged cells might appear or not depending on parser.
    // XML Parser: SimpleXML iteration usually gives all cells.
    // Let's create a map of Column Index -> Subject Name
    
    $subjectMap = []; // ColIndex => SubjectName
    $colLimit = count($headerRow1);
    
    for ($i = 2; $i < $colLimit; $i++) {
        $val = trim($headerRow1[$i]);
        if (!empty($val)) {
            $subjectMap[$i] = $val; // CA Column for this subject
            // The next column ($i+1) is Exam for the same subject.
        }
    }

    // Get DB Subjects to match Names -> IDs
    $stmt = $db->prepare("SELECT id, subject_name FROM subjects");
    $stmt->execute();
    $dbSubjects = $stmt->fetchAll(PDO::FETCH_KEY_PAIR); // ID => Name
    // Flip to Name => ID for lookup (normalize case)
    $dbSubjectIds = [];
    foreach ($dbSubjects as $id => $name) {
        $dbSubjectIds[strtoupper(trim($name))] = $id;
    }

    // Prepare Statements
    $stmtCheck = $db->prepare("SELECT id FROM student_results WHERE student_id = ? AND class_id = ? AND subject_id = ? AND session_id = ? AND term_id = ?");
    $stmtInsert = $db->prepare("
        INSERT INTO student_results (student_id, class_id, subject_id, session_id, term_id, ca_score, exam_score, grade, remark)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $stmtUpdate = $db->prepare("
        UPDATE student_results 
        SET ca_score = ?, exam_score = ?, grade = ?, remark = ?
        WHERE id = ?
    ");

    $db->beginTransaction();
    $processed = 0;

    // 3. Process Data Rows (Start from Row 3, index 2)
    for ($r = 2; $r < count($rows); $r++) {
        $row = $rows[$r];
        if (empty($row[0])) continue; // Skip if no Admission No
        
        $admissionNo = trim($row[0]); // Admission No (Student ID in users table logic?)
        
        // Find Student internal ID
        $stmtStu = $db->prepare("SELECT id FROM students WHERE student_id = ? AND class_id = ?");
        $stmtStu->execute([$admissionNo, $class_id]);
        $studentInternalId = $stmtStu->fetchColumn();
        
        if (!$studentInternalId) continue; // Student not found in this class
        
        // Iterate Subjects
        foreach ($subjectMap as $colIndex => $subName) {
            $subNameUpper = strtoupper($subName);
            $subjectId = $dbSubjectIds[$subNameUpper] ?? null;
            
            if (!$subjectId) continue; // Unknown subject in header
            
            // Get Scores
            // CA is at $colIndex, Exam is at $colIndex + 1
            $ca = isset($row[$colIndex]) ? floatval($row[$colIndex]) : 0;
            $exam = isset($row[$colIndex + 1]) ? floatval($row[$colIndex + 1]) : 0;
            
            // Validation
            $ca = min(30, max(0, $ca));
            $exam = min(70, max(0, $exam));
            
            $total = $ca + $exam; // DB generated column handles this, but we need it for Grade
            
            // Grading
            $grade = 'F';
            $remark = 'FAIL';
            if ($total >= 70) { $grade = 'A'; $remark = 'PASS'; }
            elseif ($total >= 60) { $grade = 'B'; $remark = 'PASS'; }
            elseif ($total >= 50) { $grade = 'C'; $remark = 'PASS'; }
            elseif ($total >= 45) { $grade = 'D'; $remark = 'PASS'; }
            elseif ($total >= 40) { $grade = 'E'; $remark = 'PASS'; }
            
            // Save
            $stmtCheck->execute([$studentInternalId, $class_id, $subjectId, $session_id, $term_id]);
            $existingId = $stmtCheck->fetchColumn();
            
            if ($existingId) {
                $stmtUpdate->execute([$ca, $exam, $grade, $remark, $existingId]);
            } else {
                $stmtInsert->execute([$studentInternalId, $class_id, $subjectId, $session_id, $term_id, $ca, $exam, $grade, $remark]);
            }
        }
        $processed++;
    }

    // 4. Calculate Positions (Post-Process)
    // Needs to sum totals per student, rank them, and update 'position' column.
    // This is complex per subject vs per class.
    // Prompt: "Position must be calculated per class ... Based on total aggregate score".
    // We need to sum up total_scores for all subjects for each student in this session/term/class.
    
    // Step A: Get Aggregates
    $stmtAgg = $db->prepare("
        SELECT student_id, SUM(ca_score + exam_score) as aggregate 
        FROM student_results
        WHERE class_id = ? AND session_id = ? AND term_id = ?
        GROUP BY student_id
        ORDER BY aggregate DESC
    ");
    $stmtAgg->execute([$class_id, $session_id, $term_id]);
    $rankings = $stmtAgg->fetchAll(PDO::FETCH_ASSOC);
    
    // Step B: Update Positions
    $rank = 1;
    $prevScore = -1;
    $displayRank = 1;
    
    $stmtUpdatePos = $db->prepare("UPDATE student_results SET position = ? WHERE student_id = ? AND class_id = ? AND session_id = ? AND term_id = ?");
    // Wait/Note: Position is usually per student per term (overall), stored where?
    // My table `student_results` has `position` column.
    // If I update `position` on EVERY subject row, it works (redundant but effective).
    
    foreach ($rankings as $i => $ranking) {
        if ($prevScore != $ranking['aggregate']) {
             $displayRank = $rank;
        }
        $prevScore = $ranking['aggregate'];
        
        // Update ALL subject records for this student with the class position
        $stmtUpdatePos->execute([$displayRank, $ranking['student_id'], $class_id, $session_id, $term_id]);
        
        $rank++;
    }

    $db->commit();
    echo json_encode(['success' => true, 'message' => "Successfully processed results for $processed students."]);

} catch (Exception $e) {
    if (isset($db) && $db->inTransaction()) {
        $db->rollBack();
        error_log("Results upload transaction rolled back: " . $e->getMessage() . " for user {$_SESSION['user_id']}");
    }
    error_log("Results upload fatal error: " . $e->getMessage() . " | File: " . ($fileName ?? 'unknown') . " | User: {$_SESSION['user_id']} | Stack: " . $e->getTraceAsString());
    echo json_encode([
        'success' => false, 
        'message' => 'An error occurred while processing the results. Please check the file format and try again. If the problem persists, contact support.'
    ]);
}
